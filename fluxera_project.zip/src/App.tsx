import Index from "./pages/Index";
export default function App() {
  return <Index />;
}