export default function LatestListings() {
  return <h3>Latest Listings</h3>;
}