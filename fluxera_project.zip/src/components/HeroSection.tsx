export default function HeroSection() {
  return (
    <section style={{ padding: 40 }}>
      <h1>Borrow Instead of Buy</h1>
      <input placeholder="Search items..." />
    </section>
  );
}