export default function Footer() {
  return <footer style={{ padding: 40 }}>© Fluxera</footer>;
}