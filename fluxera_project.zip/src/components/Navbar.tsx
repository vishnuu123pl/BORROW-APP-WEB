export default function Navbar() {
  return (
    <nav style={{ padding: 20, borderBottom: "1px solid #222" }}>
      <h2>Fluxera</h2>
    </nav>
  );
}