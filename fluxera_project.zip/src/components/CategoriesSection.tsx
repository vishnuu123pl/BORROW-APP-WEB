export default function CategoriesSection() {
  return <h3>Categories</h3>;
}